WB CORP FINANCE — Maison Noctelle / Fantasy Kisses

Application web indépendante, avec :
- Nom principal : WB CORP
- Boutique suivie : Maison Noctelle — Fantasy Kisses
- 11 commandes initiales d'octobre 2026 issues uniquement de FantasyKisses
- Chiffre d'affaires : 693,81 €
- Coût fournisseurs : 208,49 €
- Frais Etsy : 135,46 €
- Bénéfice : 349,86 €
- Flèches pour naviguer entre les mois
- Objectif de bénéfice mensuel de 3 000 €
- Formulaire simple : date, produit, prix de vente, coût fournisseur, frais Etsy, statut, notes
- Connexion Supabase Auth et synchronisation via la table public.sales, sous réserve de règles RLS compatibles

Déploiement Netlify :
1. Décompresse ce ZIP.
2. Va sur https://app.netlify.com/drop
3. Dépose le dossier contenant index.html.
4. Ouvre le site publié.

Supabase :
1. Clique sur Connexion.
2. Renseigne l'URL du projet et la clé publique publishable/anon.
3. Connecte-toi avec un utilisateur existant dans Supabase Auth.
4. Si la connexion échoue, les politiques RLS de public.sales doivent être compatibles avec l'identifiant de cet utilisateur. Ne désactive pas RLS et ne mets jamais la clé service_role dans le navigateur.

Important : le code de l'application est prêt à être déployé, mais la synchronisation n'est confirmée qu'après un test réel de connexion au projet Supabase.
